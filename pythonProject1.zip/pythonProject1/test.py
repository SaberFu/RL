import Spider
import math

setpoint0 = [-0, 65,  0, -70,  0, -70,  0, 65,   0, 70,   0, -65]
setpoint1 = [30, 30, 30, -70, 30, -70, 30, 30, -30, 70, -30, -30]
setpoint2 = [30, 70, 30, -65, 30, -65, 30, 70, -30, 65, -30, -70]
setpoint3 = [-0, 70,  0, -30,  0, -30,  0, 70,   0, 30,   0, -70]

array_list = [setpoint0, setpoint1, setpoint2, setpoint3]
array_list = [[math.radians(x) for x in y] for y in array_list]

spider = Spider.Env()

while spider.data.time < spider.duration:
    spider.step_count += 1
    if spider.step_count % 50 == 0:
        spider.order_count += 1
        print(spider.order_count)
        print(["{:.2f}".format(y) for y in [math.degrees(x) for x in spider.data.qpos[7:19]]])

    spider.step(array_list[spider.order_count % 4], True)

spider.export()
