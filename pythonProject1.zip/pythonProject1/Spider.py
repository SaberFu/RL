import mujoco as mj
import numpy as np
import math
import csv
import cv2


class Env:
    @staticmethod
    def quaternion_to_euler(x, y, z, w):
        t0 = +2.0 * (w * x + y * z)
        t1 = +1.0 - 2.0 * (x * x + y * y)
        roll_x = math.atan2(t0, t1)

        t2 = +2.0 * (w * y - z * x)
        t2 = +1.0 if t2 > +1.0 else t2
        t2 = -1.0 if t2 < -1.0 else t2
        pitch_y = math.asin(t2)

        t3 = +2.0 * (w * z + x * y)
        t4 = +1.0 - 2.0 * (y * y + z * z)
        yaw_z = math.atan2(t3, t4)

        result = [roll_x, pitch_y, yaw_z]

        return [math.degrees(rad) for rad in result]

    @staticmethod
    def command(vector):
        tmp = [30, 20, 30, 20, 30, 20, 30, 20, 30, 20, 30, 20] * vector
        tmp = tmp + [0, 50, 0, 50, 0, 50, 0, 50, 0, 50, 0, 50]
        tmp = tmp * [1, 1, 1, -1, 1, -1, 1, 1, 1, 1, 1, -1]
        return [math.radians(x) for x in tmp]

    @staticmethod
    def images_to_video(images, output_file='output.mp4', fps=30):
        # 获取图像尺寸
        height, width, _ = images[0].shape

        # 创建VideoWriter对象
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # 使用mp4编码器
        video_writer = cv2.VideoWriter(output_file, fourcc, fps, (width, height))

        # 将图像写入视频文件
        for image in images:
            video_writer.write(image)

        # 释放VideoWriter对象
        video_writer.release()

    def __init__(self):
        # RL settings
        self._healthy_reward = 0.1
        self._ctrl_cost_weight = 0.2
        self._average_speed_weight = 5

        self.reward = 0

        # Mujoco settings
        self.model = mj.MjModel.from_xml_path("ant2_position.xml")
        self.data = mj.MjData(self.model)
        self.duration = 25  # (seconds)

        self.step_count = 0
        self.order_count = 0
        self.per_action = [0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1]
        self.frames = []

        self.pos = []
        self.motor = []
        self.vel = []
        self.sensor = []

        self.observation_space = 18
        self.action_space = 12

        # Make a camera.
        self.cam = mj.MjvCamera()
        mj.mjv_defaultCamera(self.cam)
        self.cam.distance = 8
        self.cam.azimuth = 120
        self.cam.elevation = -60
        self.cam.lookat = np.array([0, 0, 1])

        self.render = False
        self.csv = False

        mj.mj_resetData(self.model, self.data)  # Reset state and time.

    def step(self, action, changed=False):
        self.per_action = action
        if changed:
            self.data.ctrl = action
        else:
            self.data.ctrl = self.command(action)
        mj.mj_step(self.model, self.data)

        reward, reward_info = self._get_rew(self.data.qpos[1])
        self.reward += reward

        if self.render:
            if len(self.frames) < self.step_count / 5:
                with mj.Renderer(self.model, 480, 640) as renderer:
                    renderer.update_scene(self.data, self.cam)
                    pixels = renderer.render()
                    self.frames.append(pixels)

        self.vel.append(list(self.data.qvel))
        self.sensor.append(list(self.data.sensordata))
        self.motor.append(list(self.data.qpos[7:19]))
        self.pos.append(list(self.data.qpos[:3]) + list(self.quaternion_to_euler(*self.data.qpos[3:7])))

        return self._get_obs(), reward, False

    def reset(self):
        mj.mj_resetData(self.model, self.data)
        del self.pos[:]
        del self.motor[:]
        del self.vel[:]
        del self.sensor[:]
        self.step_count = 0
        self.order_count = 0
        del self.frames[:]
        self.reward = 0
        return self._get_obs()

    def export(self):
        if self.render:
            self.images_to_video(self.frames)

        if self.csv:
            with (open('output.csv', 'w', newline='', encoding='utf-8') as csvfile):
                writer = csv.writer(csvfile)
                for i in range(len(self.sensor)):
                    row = self.pos[i] + self.motor[i] + self.vel[i] + self.sensor[i]
                    row = ["{:.4f}".format(x) for x in row]
                    writer.writerow(row)

        print(self.reward)

    @property
    def is_healthy(self):
        if 0.85 > self.data.qpos[2] > 0.47:
            is_healthy = 1
        else:
            is_healthy = 0
        return is_healthy

    @property
    def healthy_reward(self):
        return self.is_healthy * self._healthy_reward

    def control_cost(self):
        if len(self.motor) == 0:
            pre_pos = self.data.qpos[7:19]
        else:
            pre_pos = self.motor[-1]

        control_cost = self._ctrl_cost_weight * np.sum(np.square(self.data.qpos[7:19] - pre_pos)) * 1000
        return control_cost

    def _get_rew(self, y_pos):
        if len(self.pos) < 500:
            pre_y_pos = self.data.qpos[1]
        else:
            pre_y_pos = self.pos[-500][1]

        y_velocity = (y_pos - pre_y_pos) / 5
        average_speed_reward = y_velocity * self._average_speed_weight
        healthy_reward = self.healthy_reward
        rewards = average_speed_reward + healthy_reward

        costs = self.control_cost()
        reward = rewards - costs

        reward_info = {
            "average_speed_reward": average_speed_reward,
            "reward_ctrl": -costs,
            "reward_survive": healthy_reward,
        }

        return reward, reward_info

    def _get_obs(self):
        state = list(self.data.sensordata) + list(self.per_action)
        return state
