import math
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.distributions import MultivariateNormal
from torch.distributions import Categorical
import gymnasium as gym
import numpy as np

import Spider

# Hyperparameters
gamma = 0.99
lambda_gae = 0.95
clip_epsilon = 0.2
learning_rate = 3e-4
K_epochs = 10
update_timestep = 4000
max_episodes = 50000
max_timesteps = 50
entropy_coef = 0.01
critic_loss_coef = 0.5


class ActorCritic(nn.Module):
    def __init__(self, input_dim, action_dim, action_std_init=0.6):
        super(ActorCritic, self).__init__()

        # Actor network
        self.actor = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.Tanh(),
            nn.Linear(64, 64),
            nn.Tanh(),
            nn.Linear(64, action_dim)
        )

        # Critic network
        self.critic = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.Tanh(),
            nn.Linear(64, 64),
            nn.Tanh(),
            nn.Linear(64, 1)
        )

        # Action log standard deviation
        self.action_var = torch.full((action_dim,), action_std_init * action_std_init).to(device)

    def forward(self):
        raise NotImplementedError

    def act(self, state):
        # crete action space
        action_mean = self.actor(state)
        cov_mat = torch.diag(self.action_var).unsqueeze(0)
        dist = MultivariateNormal(action_mean, cov_mat)

        action = dist.sample()
        action_logprob = dist.log_prob(action)
        return action, action_logprob

    def evaluate(self, state, action):
        action_mean = self.actor(state)
        cov_mat = torch.diag(self.action_var).unsqueeze(0)
        dist = MultivariateNormal(action_mean, cov_mat)

        action_logprobs = dist.log_prob(action)
        dist_entropy = dist.entropy()
        state_value = self.critic(state)

        return action_logprobs, torch.squeeze(state_value), dist_entropy


class PPO:
    def __init__(self, input_dim, action_dim, action_std_init=0.6):
        self.policy = ActorCritic(input_dim, action_dim, action_std_init).to(device)
        self.optimizer = optim.Adam(self.policy.parameters(), lr=learning_rate)

        self.policy_old = ActorCritic(input_dim, action_dim, action_std_init).to(device)
        self.policy_old.load_state_dict(self.policy.state_dict())

        self.MseLoss = nn.MSELoss()

    def select_action(self, state, memory):
        state = torch.FloatTensor(state).to(device)
        action, action_logprob = self.policy_old.act(state)

        memory.states.append(state)
        memory.actions.append(action)
        memory.logprobs.append(action_logprob)

        return action.cpu().data.numpy().flatten()

    def update(self, memory):
        rewards = []
        discounted_reward = 0
        for reward, is_terminal in zip(reversed(memory.rewards), reversed(memory.is_terminals)):
            if is_terminal:
                discounted_reward = 0
            discounted_reward = reward + (gamma * discounted_reward)
            rewards.insert(0, discounted_reward)

        rewards = torch.tensor(rewards, dtype=torch.float32).to(device)
        old_states = torch.stack(memory.states).to(device)
        old_actions = torch.stack(memory.actions).to(device)
        old_logprobs = torch.stack(memory.logprobs).to(device)

        for _ in range(K_epochs):
            logprobs, state_values, dist_entropy = self.policy.evaluate(old_states, old_actions)

            advantages = rewards - state_values.detach()
            ratios = torch.exp(logprobs - old_logprobs.detach())

            surr1 = ratios * advantages
            surr2 = torch.clamp(ratios, 1 - clip_epsilon, 1 + clip_epsilon) * advantages
            loss = (-torch.min(surr1, surr2) + critic_loss_coef * self.MseLoss(state_values, rewards)
                    - entropy_coef * dist_entropy)

            self.optimizer.zero_grad()
            loss.mean().backward()
            self.optimizer.step()

        self.policy_old.load_state_dict(self.policy.state_dict())


class Memory:
    def __init__(self):
        self.actions = []
        self.states = []
        self.logprobs = []
        self.rewards = []
        self.is_terminals = []

    def clear_memory(self):
        del self.actions[:]
        del self.states[:]
        del self.logprobs[:]
        del self.rewards[:]
        del self.is_terminals[:]


def main():
    spider = Spider.Env()
    state_dim = spider.observation_space
    action_dim = spider.action_space

    ppo_agent = PPO(state_dim, action_dim)
    memory = Memory()

    # Load the saved model (if exists)
    try:
        checkpoint = torch.load('ppo_ant_model.pth', weights_only=True)
        ppo_agent.policy.load_state_dict(checkpoint['model_state_dict'])
        ppo_agent.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        print("Model loaded from ppo_ant_model.pth")
    except FileNotFoundError:
        print("No saved model found, starting fresh.")

    timestep = 0

    for episode in range(max_episodes):
        state = spider.reset()
        for t in range(max_timesteps):
            timestep += 1
            spider.step_count += 1

            action = ppo_agent.select_action(state, memory)

            state = np.zeros(18)
            reward = 0
            for _ in range(50):
                state_tmp, reward_tmp, done = spider.step(np.array([math.tanh(x) for x in action]))
                state += state_tmp
                reward += reward_tmp

            memory.rewards.append(reward)
            memory.is_terminals.append(done)

            if timestep % update_timestep == 0:
                ppo_agent.update(memory)
                memory.clear_memory()

            if done:
                break

        print(f"Reward {spider.reward}")

        if episode % 10 == 0:
            print(f"Episode {episode}, Timestep {timestep}")

    torch.save(
        {
            'model_state_dict': ppo_agent.policy.state_dict(),
            'optimizer_state_dict': ppo_agent.optimizer.state_dict()
        }, 'ppo_ant_model.pth')


if __name__ == "__main__":
    device = torch.device("cpu")
    main()
